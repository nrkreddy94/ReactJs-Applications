import React from "react";
import ReactDOM from "react-dom";

import './styles/App.css'
import Dashboard from "./components/DashBoard/DashBoard.js";
ReactDOM.render(<Dashboard />, document.getElementById("root"));


