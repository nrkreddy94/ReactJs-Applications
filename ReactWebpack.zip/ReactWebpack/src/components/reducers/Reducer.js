import {  SUBMITTED } from './../actions/actions';

const initialState = {
  isLoading: false,
  person: {
    user: '',
    email: '',
    password:'' 
  }
};

export function reducer (state = initialState, action) {
  switch (action.type) {
      case SUBMITTED:
       return Object.assign({}, state, {
        person: action.person,
        isLoading: true
      });
    default:
      return state;
  }
}
