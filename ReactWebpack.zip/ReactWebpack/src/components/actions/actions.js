/* eslint-disable no-use-before-define */


export const SUBMITTED = 'SUBMITTED';
function submitPerson (person) {
  return {type: SUBMITTED, person};
}

export { submitPerson};