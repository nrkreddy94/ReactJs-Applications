import React from "react";
import { connect } from 'react-redux';
import GridContainer from './kendoGrid'
class Results extends React.Component {

    constructor(props, context) {
        super(props, context);
    }


    render() {
        return (
            <div style={{ paddingLeft: '5%' }}>

                {this.props.person.user.length ? <GridContainer /> : ''}

            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        isLoading: state.isLoading,
        person: state.person,
    };
}


export default connect(mapStateToProps)(Results);
