import React from "react";
import PropTypes from 'prop-types';

class SearchForm extends React.Component {

    state = {
        isLoading: false,
        person: {
            user: '',
            email: '',
            password: ''
        }
    };


    onFormSubmit = (evt) => {
         evt.preventDefault();
        const person = this.state.person;
        if (this.validate()) return;
        console.log('Before Submit :' + person);
        this.props.onSubmit(person);
    };


    onInputChange = (e) => {
        const person = this.state.person;
        person[e.target.name] = e.target.value
        this.setState({ person });

    };


    validate = () => {
        const person = this.state.person;

        if (!person.user) return true;
        if (!person.email) return true;
        if (!person.password) return true;

        return false;
    };

    render() {
          
        return (
            <div style={{padding:'5% 10%', background: 'rgb(240, 240, 240)'}}>
                <h2>Search Form</h2>
                <form class="form-horizontal" onSubmit={this.onFormSubmit} style={{ width: '90%', paddingLeft: '10px' }}>
                    <div class="form-group">
                        <label class="control-label col-sm-2" htmlFor="userName">UserName:</label>
                        <input type="text" class="form-control" id="user"
                            placeholder="Enter UserName" name="user" onChange={this.onInputChange}
                            value={this.state.person.user}></input>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" htmlFor="email">Email:</label>
                        <input type="email" class="form-control" id="email"
                            placeholder="Enter Email" name="email" onChange={this.onInputChange}
                            value={this.state.person.email}></input>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" htmlFor="password">Password:</label>
                        <input type="text" class="form-control" id="password"
                            placeholder="Enter Password" name="password" onChange={this.onInputChange}
                            value={this.state.person.password}></input>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-3 col-sm-10">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        );
    }
}

export default SearchForm;