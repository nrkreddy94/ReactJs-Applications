import React, { Component } from "react";
import './../../styles/footer.css';
class Footer extends Component {

    render() {

        return (
            <div className="site-footer">
                <div className="container">
                    <div className="row">
                        <div className="col-md-8 col-sm-6 col-xs-12" style={{padding:'10px'}}>
                            <p className="copyright-text">Copyright &copy; 2019 All Rights Reserved by
                        <a href="#"> TRAX</a>.
                         </p>
                        </div>

                        <div className="col-md-4 col-sm-6 col-xs-12">
                            <ul className="social-icons">
                                <li><a className="facebook" href="#"><i className="fa fa-facebook"></i></a></li>
                                <li><a className="twitter" href="#"><i className="fa fa-twitter"></i></a></li>
                                <li><a className="dribbble" href="#"><i className="fa fa-dribbble"></i></a></li>
                                <li><a className="linkedin" href="#"><i className="fa fa-linkedin"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Footer;