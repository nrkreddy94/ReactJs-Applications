import React, { Component } from "react";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import Header from "./../Header/Header";
import Footer from "./../Footer/Footer";
import Body from "./../DashBoard/Body";


class Dashboard extends Component {

    render() {
        return (
            <Router>
                <Header />
                <Body />
                <Footer />
            </Router>
        );

    }
}

export default Dashboard;




