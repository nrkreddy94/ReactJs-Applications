import React, { Component } from "react";
import Results from './../Body/Results'
import SearchForm from './../Body/SearchForm'
import thunkMiddleware from 'redux-thunk';
import { connect, Provider } from 'react-redux';
import { createStore, applyMiddleware } from 'redux';
import { reducer } from './../reducers/Reducer';
import { submitPerson } from './../actions/actions';

const store = createStore(reducer, applyMiddleware(thunkMiddleware));
const ReduxSearchForm = connect(mapStateToProps, mapDispatchToProps)(SearchForm);
class Body extends Component {

    render() {
    const td1 = {
           width:'30%',
             padddingRight:'2%',  
             position:'fixed'      
        }
   
        return (
            <Provider store={store}>
                <table>
                    <tbody>
                        <tr>
                            <td style={td1}> <ReduxSearchForm /></td>
                            <td style={{width:'70%'}}> <Results /></td>
                        </tr>

                    </tbody>
                </table>
            </Provider>

        );
    } l
}

store.subscribe(() => {console.log("Updated store:"+ store.getState().person)})

function mapStateToProps(state) {
    return {
        isLoading: state.isLoading,
        person: state.person,
    };
}

function mapDispatchToProps(dispatch) {
    return {
        onSubmit: (person) => {
            dispatch(submitPerson(person));
        },
    };
}


export default Body;