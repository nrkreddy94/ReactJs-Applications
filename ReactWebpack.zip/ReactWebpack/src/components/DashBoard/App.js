import React, { Component } from "react";

import './../../styles/App.css';
import jpglogo from './../../images/Jellyfish.jpg'
import favicon from  './../../images/favicon.ico'
import svglog from './../../images/logo.svg'
import data from './../Data/data.json';


class App extends Component {

    state = { username: null };
      componentDidMount() {
    fetch('/api/getUsername')
      .then(res => res.json())
      .then(user => this.setState({ username: user.username }));
  }
    render() {

        const imgStyle = {
           height:'300px',
           width:'300px'
        };

        return (
            <div>
              <h1>My React App!</h1>
                <table>
                    <tbody>
                    <tr>
                    <td> <img src={jpglogo} style={imgStyle}/></td>
                    <td> <img src={favicon} style={imgStyle}/></td>
                    <td><div style={imgStyle}>
            <span dangerouslySetInnerHTML={{__html: svglog}} />
            </div></td>
                    </tr>
                </tbody>
                </table>
            
                
                <p>Welcome Jagadeesh</p>
                <p>{data.greetText}</p>
                 {this.state.username ? <h1>{`Hello ${this.state.username}`}</h1> : <h1>Loading.. please wait!</h1>}
            </div>
        );
    }
}

export default App;