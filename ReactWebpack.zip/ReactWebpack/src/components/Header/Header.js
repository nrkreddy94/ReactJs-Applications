import React, { Component } from "react";
import NavigationBarLogo from './NavigationBarLogo'
import NavigationBarProfile from './NavigationBarProfile'
import NavigationBarMenu from './NavigationBarMenu'

   
class Header extends Component {

    render() {
        return (
            <div>
                <nav className="navbar navbar-inverse">
                    <div className="container-fluid">
                        <NavigationBarLogo />
                        <NavigationBarMenu />
                        <NavigationBarProfile />
                    </div>
                </nav>
            </div>
        );
    }
}

export default Header;