import React, { Component } from "react";
import { Link } from "react-router-dom";
import logo from './../../images/fntg.png'
class NavigationBarLogo extends Component {

    render() {
        return (

            <div className="navbar-header">
                <Link to='/' className="navbar-brand">
                    TRAX
                </Link>
            </div>

        );
    }
}

export default NavigationBarLogo;