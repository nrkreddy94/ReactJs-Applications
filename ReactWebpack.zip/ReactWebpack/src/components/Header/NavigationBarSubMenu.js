import React, { Component } from "react";
import { Link } from "react-router-dom";
class NavigationBarSubMenu extends Component {

    render() {
        return (
            <li className="dropdown"><Link className="dropdown-toggle" data-toggle="dropdown" to="">Page 1 <span className="caret"></span></Link>
                <ul className="dropdown-menu">
                    <li><Link to="/Page1-1">Page1-1</Link></li>
                    <li><Link to="/Page1-2">Page1-2</Link></li>
                    <li><Link to="/Page1-3">Page1-3</Link></li>
                </ul>
            </li>
        );
    }
}

export default NavigationBarSubMenu;