import React, { Component } from "react";
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
class NavigationBarProfile extends Component {

    render() {
        return (

            <ul className="nav navbar-nav navbar-right">
                <li> <Link to="/proflie"> <span className="glyphicon glyphicon-user"></span> User Name</Link></li>
                <li> <Link to="/logout"><span className="glyphicon glyphicon-log-out"></span> Logout</Link> </li>
            </ul>

        );
    }
}

export default NavigationBarProfile;