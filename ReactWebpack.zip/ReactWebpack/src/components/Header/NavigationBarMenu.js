import React, { Component } from "react";
import { Link } from "react-router-dom";
import NavigationBarSubMenu from './NavigationBarSubMenu'
class NavigationBarMenu extends Component {

    render() {
        return (
            <ul className="nav navbar-nav">
                <li className="active"><Link to='/home'>Home</Link></li>
                <NavigationBarSubMenu />
                <li><Link to='/page2'>Page 2</Link> </li>
            </ul>
        );
    }
}

export default NavigationBarMenu;