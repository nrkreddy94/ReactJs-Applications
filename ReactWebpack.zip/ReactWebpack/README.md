# Simple React Webpack boilerplate

A ready to use simple boilerplate for React Apps.

## Instructions

* Clone the repo
* Run `npm install`
* Run `npm start`
