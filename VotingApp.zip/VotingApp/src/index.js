import React from 'react';
import ReactDOM from 'react-dom';
import ProductList from './components/ProductList.js'

ReactDOM.render(<ProductList/>, document.getElementById('root'));
