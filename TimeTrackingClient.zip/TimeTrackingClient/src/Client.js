
class Client {
    static getHost() {
        return "http://localhost:3030"
    }

    static getTimers(success) {
        return fetch(this.getHost() + '/api/timers', {
            headers: {
                Accept: 'application/json'
                 
            },
        }).then(this.checkStatus)
            .then(this.parseJSON)
            .then(success);
    }

    static createTimer(data) {
        return fetch(this.getHost() + '/api/timers', {
            method: 'post',
            body: JSON.stringify(data),
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
        }).then(this.checkStatus);
    }

    static updateTimer(data) {
        return fetch(this.getHost() + '/api/timers', {
            method: 'put',
            body: JSON.stringify(data),
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
        }).then(this.checkStatus);
    }

    static deleteTimer(data) {
        return fetch(this.getHost() + '/api/timers', {
            method: 'delete',
            body: JSON.stringify(data),
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
        }).then(this.checkStatus);
    }

    static startTimer(data) {
        return fetch(this.getHost() + '/api/timers/start', {
            method: 'post',
            body: JSON.stringify(data),
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
        }).then(this.checkStatus);
    }

    static stopTimer(data) {
        return fetch(this.getHost() + '/api/timers/stop', {
            method: 'post',
            body: JSON.stringify(data),
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
        }).then(this.checkStatus);
    }

    static checkStatus(response) {
        if (response.status >= 200 && response.status < 300) {
            return response;
        } else {
            const error = new Error(`HTTP Error ${response.statusText}`);
            error.status = response.statusText;
            error.response = response;
            console.log(error);
            throw error;
        }
    }

    static parseJSON(response) {
        return response.json();
    }

}
export default Client