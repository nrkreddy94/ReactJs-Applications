import React from 'react'
import EditableTimer from './EditableTimer'
class EditableTimerList extends React.Component {

    render() {
        const Components = this.props.timers.map((timer) =>
            <EditableTimer key={timer.id}
                id={timer.id}
                title={timer.title}
                project={timer.project}
                elapsed={timer.elapsed}
                runningSince={timer.runningSince}
                editFormOpen={timer.editFormOpen}
                onFormSubmit={this.props.onFormSubmit}
                onTrashClick={this.props.onTrashClick}
                onStartClick={this.props.onStartClick}
                onStopClick={this.props.onStopClick}
            />
        );
        return (

            <div id='timers'>
                {Components}
            </div>
        )
    }
}
export default EditableTimerList