import React from 'react'
import ToggleTimerForm from './ToogleTimerForm'
import EditableTimerList from './EditableTimerList'
import client from './../Client'
import helpers from './../Helpers.js'

class TimerDashboard extends React.Component {
    constructor() {
        super()
        this.state = {
            timers: []
        };
        this.loadTimersFromServer();
        setInterval(this.loadTimersFromServer, 5000);
    }


    loadTimersFromServer = () => {
        client.getTimers((serverTimers) => (
            this.setState({ timers: serverTimers })
        )
        );
    };

    handleCreateFormSubmit = (timer) => {
        this.createTimer(timer);
    };

    createTimer = (timer) => {
        const t = helpers.newTimer(timer);
        this.setState({
            timers: this.state.timers.concat(t),
        });

        client.createTimer(t);
    };

    handleEditFormSubmit = (attrs) => {
        this.updateTimer(attrs);
    };
    updateTimer = (attrs) => {
        this.setState({
            timers: this.state.timers.map((timer) => {
                if (timer.id === attrs.id) {
                    return Object.assign({}, timer, {
                        title: attrs.title,
                        project: attrs.project,
                    });
                } else {
                    return timer;
                }
            }),
        });
        client.updateTimer(attrs)
    };

    handleTrashClick = (timerId) => {
        this.deleteTimer(timerId);
    };

    deleteTimer = (timerId) => {
        this.setState({
            timers: this.state.timers.filter(t => t.id !== timerId),
        });
        client.deleteTimer({ id: timerId})
    };
    handleStartClick = (timerId) => {
        this.startTimer(timerId);
    };
    startTimer = (timerId) => {
        const now = Date.now();

        this.setState({
            timers: this.state.timers.map((timer) => {
                if (timer.id === timerId) {
                    return Object.assign({}, timer, {
                        runningSince: now,
                    });
                } else {
                    return timer;
                }
            }),
        });
        client.startTimer({ id: timerId, start: now })
    };
    handleStopClick = (timerId) => {
        this.stopTimer(timerId);
    };
    stopTimer = (timerId) => {
        const now = Date.now();

        this.setState({
            timers: this.state.timers.map((timer) => {
                if (timer.id === timerId) {
                    const lastElapsed = now - timer.runningSince;
                    return Object.assign({}, timer, {
                        elapsed: timer.elapsed + lastElapsed,
                        runningSince: null,
                    });
                } else {
                    return timer;
                }
            }),
        });
        client.stopTimer(
            { id: timerId, stop: now }
        );
    };
    render() {

        return (
            <div>
                <EditableTimerList timers={this.state.timers}
                    onFormSubmit={this.handleEditFormSubmit}
                    onTrashClick={this.handleTrashClick}
                    onStartClick={this.handleStartClick}
                    onStopClick={this.handleStopClick} />
                <ToggleTimerForm onFormSubmit={this.handleCreateFormSubmit} />
            </div>

        );
    }
}
export default TimerDashboard