import React from 'react';
import ReactDOM from 'react-dom';

import TimerDashboard from './components/TimersDashboard'

ReactDOM.render(<TimerDashboard/>, document.getElementById('root'));
