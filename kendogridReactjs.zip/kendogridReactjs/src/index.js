import React from 'react';
import ReactDOM from 'react-dom';
import GridContainer from './components/kendoGrid'
ReactDOM.render(<GridContainer/>, document.getElementById('root'));
