import React from 'react';

export class Renderers {
    constructor(enterEdit, exitEdit, editFieldName) {
        this.rowRender = this.rowRender.bind(this);
    }


    rowRender(trElement, dataItem) {
        const trProps = {
            ...trElement.props,
            onDoubleClick: () => {
              console.log('Double click on '+ dataItem.dataItem.ProductName)
            },
            onContextMenu : (e) => {
              e.preventDefault()
              console.log('Right Click on '+ dataItem.dataItem.ProductName)
            },
        };
        return React.cloneElement(trElement, { ...trProps }, trElement.props.children);
    }
}