import React from 'react';
import kendo from'@progress/kendo-ui';
import { Grid, GridColumn } from '@progress/kendo-grid-react-wrapper';
import { Renderers } from './Renderers';
class GridContainer extends React.Component {
    constructor(props) {
        super(props);
        this.renderers = new Renderers();
        this.dataSource = new kendo.data.DataSource({
            transport: {
                read:  {
                    url:"https://demos.telerik.com/kendo-ui/service/Products",
                    dataType: "jsonp"
                },
                update: {
                    url: "https://demos.telerik.com/kendo-ui/service/Products/Update",
                    dataType: "jsonp"
                },
                destroy: {
                    url: "https://demos.telerik.com/kendo-ui/service/Products/Destroy",
                    dataType: "jsonp"
                },
                create: {
                    url: "https://demos.telerik.com/kendo-ui/service/Products/Create",
                    dataType: "jsonp"
                },
                 parameterMap: function(options, operation) {
                    if (operation !== "read" && options.models) {
                        return {models: kendo.stringify(options.models)};
                    }
                }
            },
            batch: true,
            pageSize: 5,
            schema: {
                model: {
                    id: "ProductID",
                    fields: {
                        ProductID: { editable: false, nullable: true },
                        ProductName: { validation: { required: true } },
                        UnitPrice: { type: "number", validation: { required: true, min: 1} },
                        Discontinued: { type: "boolean" },
                        UnitsInStock: { type: "number", validation: { min: 0, required: true } }
                    }
                }
            }
        });
    }

    render() {
        return (
            <Grid dataSource={this.dataSource}
                scrollable={true} sortable={true}
                groupable={false} pageable={true}
                editable={"popup"}
                toolbar={["create"]}
                selectable={true}
                rowRender={this.renderers.rowRender}
                >
                <GridColumn field="ProductID" template="#:ProductID# - #:ProductName#" title="Product Name" />
                <GridColumn field="UnitPrice" title="Unit Price" format="{0:c}"  />
                <GridColumn field="UnitsInStock" title="Units in Stock"  />
                <GridColumn field="Discontinued"  />
                <GridColumn command={["edit", "destroy"]} title="Actions" />
            </Grid>
        );
    }
}

export default GridContainer;