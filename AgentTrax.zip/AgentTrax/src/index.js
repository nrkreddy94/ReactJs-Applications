import React from "react";
import ReactDOM from "react-dom";

//import './css/bootstrap.min.css'
import './css/bootstrap-dialog.min.css'
//import './fonts/fontawesome-webfont.woff2'
//import './css/font-awesome.min.css'
import './css/jquery.qtip.min.css'
import './css/toastr.min.css'
import './css/normalize.min.css'
import './css/agency-layout.css'
import './css/jacket-trax.css'





ReactDOM.render(<h1>Hello</h1>, document.getElementById("root"));


