/// <reference path="jquery-1.11.1.js" />
if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
  var msViewportStyle = document.createElement('style')
  msViewportStyle.appendChild(
    document.createTextNode(
      '@-ms-viewport{width:auto!important}'
    )
  )
  document.querySelector('head').appendChild(msViewportStyle)
}

(function ($) {

    $.fn.fnfAtMenu = function (options) {
        var $self = $(this);
        var settings = $.extend({ menus: [] }, options || {});
        settings.menus = settings.menus || [];

        /*
        Menu JSON example:
        {
            "id": "test_menu_item",
            "text": "Test Menu Item",
            "href": "#",
            "target": "_blank",
            "divider": false,
            "menus": [
                {
                    "id": "test_sub_menu_item",
                    "text": "Test Sub-Menu Item",
                    "href": "#",
                    "target": "_blank"
                }
            ]
        }
        */

        var idPrefix = 0; /*Track the id prefix value when binding the menu to multiple controls*/
        var $buildLink = function (menuItem, isSubMenu) {
            var $item = $('<li></li>');
            if (menuItem.divider) {
                return $item.addClass('divider');
            } else {
                var $a = $('<a></a>').attr('href', menuItem.href || '#')
                    .text(menuItem.text || menuItem.id || '')
                    .appendTo($item);
                if (menuItem.id) $a.attr('id', idPrefix ? idPrefix + '_' + menuItem.id : menuItem.id);
                if (menuItem.target) $a.attr('target', menuItem.target);
                if (!isSubMenu) $a.addClass('navbar-text-parent');
                if (!isSubMenu && menuItem.menus && menuItem.menus.length) {
                    $item.addClass('dropdown');
                    $a.addClass('dropdown-toggle').attr('data-toggle', 'dropdown')
                        .html($a.text() + ' ' + '<span class="caret"></span>');
                    var $subMenu = $('<ul></ul>').addClass('dropdown-menu').attr('role', 'menu').appendTo($item);
                    for (var x = -1, subItem; subItem = menuItem.menus[x += 1];) {
                        $buildLink(subItem, true).appendTo($subMenu);
                    }
                }
            }
            return $item;
        };//$buildLink

        return $self.each(function () {
            var $this = $(this);
            // Bind the menu from the options
            // Find the actual menu container (outermost UL)
            var $outerMenu = $this.is('ul.navbar-nav') ? $this : $this.find('ul.navbar-nav');
            if (!$outerMenu.length) {
                $outerMenu = $('<ul class="nav navbar-nav navbar-right" role="menu"></ul>').appendTo($this);
            }
            // Recursively bind the menu items to the menu element.
            for (var i = -1, menuItem; menuItem = settings.menus[i += 1];) {
                $buildLink(menuItem).insertBefore($outerMenu.find('li:last'));
            }
            idPrefix++;
        });//this.each

    };//$.fn.fnfAtMenu

    $.fn.fnfAtZenMode = function (options) {
        var $self = $(this);
        var settings = $.extend({
            mode: 0,
            cookieName: 'zen-mode'
        }, options || {});
        settings.menus = settings.menus || [];

        var zenToggle = function () {
            settings.mode = settings.mode === 0 ? 1 : 0;
            $(window.document.body).removeClass('zen-mode');
            if (settings.mode) $(window.document.body).addClass('zen-mode');
            $cookies.setItem(settings.cookieName, settings.mode.toString(), Infinity);
        };
        $self.on('click', function (e) {
            fnf.stopEvent(e);
            zenToggle();
        });
        if ($cookies.getItem(settings.cookieName) == 1) {
            zenToggle();
        }
    };//$.fn.fnfAtZenMode

}(jQuery));