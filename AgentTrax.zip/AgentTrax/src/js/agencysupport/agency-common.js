var fnf = fnf || {};

window.clear = window.clear || function () { };

/**
    acceptedFileTypes - an array of file extensions that are acceptable as uploads.
*/
fnf.acceptedFileTypes = [".txt", ".csv", ".rft", ".doc", ".docx", ".pdf", ".xls", ".xlsx", ".bmp", ".jpg", ".jpeg", ".jpe", ".tif", ".tiff", ".gif", ".png"];


/**
 * queryString - Gets the current query string parameters as an object (HashTable).
 * @returns {Object} An Object/HashTable representing all of the query string parameters.
 */
fnf.queryString = function () {
    var search = arguments.length > 0 ? arguments[0] : window.location.search;
    var params = search.substr(search.indexOf("?") + 1);
    var retVal = {};
    params = params.split("&");
    // split parameter and value into individual pieces
    for (var i = 0, p; p = params[i++];) {
        var temp = p.split("=");
        var key = decodeURIComponent(temp[0]),
            val = decodeURIComponent((temp.length > 1 ? temp[1] : ""));
        retVal[key] = val;
    }
    return retVal;
};

/**
 * stopEvent - Prevents event propagation across browser platforms, including FF, Mobile, IE, etc.
 * @param [e] {Event} The event to cancel propagation of. If not provided window.event will be used instead.
 * @returns {boolean} Always returns false.
 */
fnf.stopEvent = function (e) {
    if (!e) e = window.event;
    if (!e) return false;

    //e.cancelBubble is supported by IE -
    // this will kill the bubbling process.
    if (e.cancelBubble !== undefined) {
        e.cancelBubble = true;
    }

    e.returnValue = false;

    //e.stopPropagation works only in FireFox.
    if (e.stopPropagation) e.stopPropagation();
    if (e.preventDefault) e.preventDefault();

    return false;
}; // stopEvent

/**
 * htmlEncode - HTML Encode the string value using a jQuery hack.
 * @param value {string} The string that needs to be HTML encoded.
 * @returns {string} An HTML encoded version of the original string provided.
 */
fnf.htmlEncode = function (value) {
    return $("<div/>").text(value).html();
}; // htmlEncode

/**
 * htmlDecode - Decode the HTML string value as raw HTML/markup.
 * @param value {string} The HTML encoded markup to decode.
 * @returns {string} The HTML string that has been decoded from the original HTML encoded string passed in.
 */
fnf.htmlDecode = function (value) {
    return $("<div/>").html(value).text();
}; // htmlDecode



fnf.fileNumberRegExp = function () {
    var fileNumRegEx = /^(\w|\s|[!@#\$%\^\&*\)\(+=_\-~`\[\];,.\/?:\|'ñÑáéíóú])*$/i;
    return fileNumRegEx;
}

fnf.sanitizeFileNumber = function (value) {
    if (value == null || value.length == 0)
        return "";
    return value.replace(fnf.fileNumberRegExp(), '');
}

fnf.isFileNumberValid = function (value, useMinLength) {
    useMinLength = useMinLength != null ? useMinLength : true;
    var isGoodStandingLetter = value.toLowerCase() === 'gs';

    if (value.length > 30) {
        return ["File Number is " + value.length + " characters long, maximum size is 30.", "File Number Maximum Length Exceeded"];
    }

    useMinLength = useMinLength != null ? useMinLength : true;

    if (useMinLength && !isGoodStandingLetter && value.length < 3) {
        return ["File Number is " + value.length + " characters long, minimum size is 3 characters.", "File Number Minimum Length Not Met"];
    }

    if (value.search(fnf.fileNumberRegExp())) {
        return ['File number entered contains an invalid character. List of invalid characters: Double Quote ( “ ), Less Than( < ), Greater Than( > ), left brace ( { ), right brace( } ), Backslash( \\ ), and Long Dash ( – ).', "Invalid Character Detected"];
    }

    return [];
}

fnf.fileNumberValidation = function (value, useMinLength) {    
    if (value != null || value != "") {
        var fileNumberInvalidMessage = fnf.isFileNumberValid(value, useMinLength);
        if (fileNumberInvalidMessage.length > 0) {
            fnf.error(fileNumberInvalidMessage[0], fileNumberInvalidMessage[1]);
        }

        return fileNumberInvalidMessage.length == 0;
    }
};

/*\
|*|
|*|  :: cookies.js ::
|*|
|*|  A complete cookies reader/writer framework with full Unicode support.
|*|
|*|  Revision #1 - September 4, 2014
|*|
|*|  https://developer.mozilla.org/en-US/docs/Web/API/document.cookie
|*|  https://developer.mozilla.org/User:fusionchess
|*|
|*|  This framework is released under the GNU Public License, version 3 or later.
|*|  http://www.gnu.org/licenses/gpl-3.0-standalone.html
|*|
|*|  Syntaxes:
|*|
|*|  * docCookies.setItem(name, value[, end[, path[, domain[, secure]]]])
|*|  * docCookies.getItem(name)
|*|  * docCookies.removeItem(name[, path[, domain]])
|*|  * docCookies.hasItem(name)
|*|  * docCookies.keys()
|*|
\*/

var $cookies = {
    getItem: function (sKey) {
        if (!sKey) {
            return null;
        }
        return decodeURIComponent(document.cookie.replace(new RegExp("(?:(?:^|.*;)\\s*" + encodeURIComponent(sKey).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\=\\s*([^;]*).*$)|^.*$"), "$1")) || null;
    },
    setItem: function (sKey, sValue, vEnd, sPath, sDomain, bSecure) {
        if (!sKey || /^(?:expires|max\-age|path|domain|secure)$/i.test(sKey)) {
            return false;
        }
        var sExpires = "";
        if (vEnd) {
            switch (vEnd.constructor) {
                case Number:
                    sExpires = vEnd === Infinity ? "; expires=Fri, 31 Dec 9999 23:59:59 GMT" : "; max-age=" + vEnd;
                    break;
                case String:
                    sExpires = "; expires=" + vEnd;
                    break;
                case Date:
                    sExpires = "; expires=" + vEnd.toUTCString();
                    break;
            }
        }
        document.cookie = encodeURIComponent(sKey) + "=" + encodeURIComponent(sValue) + sExpires + (sDomain ? "; domain=" + sDomain : "") + (sPath ? "; path=" + sPath : "") + (bSecure ? "; secure" : "");
        return true;
    },
    removeItem: function (sKey, sPath, sDomain) {
        if (!this.hasItem(sKey)) {
            return false;
        }
        document.cookie = encodeURIComponent(sKey) + "=; expires=Thu, 01 Jan 1970 00:00:00 GMT" + (sDomain ? "; domain=" + sDomain : "") + (sPath ? "; path=" + sPath : "");
        return true;
    },
    hasItem: function (sKey) {
        if (!sKey) {
            return false;
        }
        return (new RegExp("(?:^|;\\s*)" + encodeURIComponent(sKey).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\=")).test(document.cookie);
    },
    keys: function () {
        var aKeys = document.cookie.replace(/((?:^|\s*;)[^\=]+)(?=;|$)|^\s*|\s*(?:\=[^;]*)?(?:\1|$)/g, "").split(/\s*(?:\=[^;]*)?;\s*/);
        for (var nLen = aKeys.length, nIdx = 0; nIdx < nLen; nIdx++) {
            aKeys[nIdx] = decodeURIComponent(aKeys[nIdx]);
        }
        return aKeys;
    }
};


fnf.formatMoney = function (n, c, d, t) {
    var n = n || 0,
        n = $.isFunction(n) ? n() : n,
        c = isNaN(c = Math.abs(c)) ? 2 : c,
        d = d == undefined ? "." : d,
        t = t == undefined ? "," : t,
        s = n < 0 ? "(" : "",
        x = n < 0 ? ")" : "",
        i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "",
        j = (j = i.length) > 3 ? j % 3 : 0;
    return s + "$" + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "") + x;
};

fnf.toNumber = function (n) {
    if (n == undefined) return NaN;
    var strvalue = n.toString();
    var num = strvalue.replace(/[ ,\,]/g, "").replace(/^[$]/, "").replace(/ /, "");
    if (num.length <= 0) return NaN;
    if (isNaN(num)) return NaN;
    var pattern = /\d*\.\d*|\d*/;
    if (num != pattern.exec(num)) return NaN;
    return new Number(num);
};


/**
 * Escapes characters in the string that are not safe to use in a RegExp.
 * @param {*} s The string to escape. If not a string, it will be casted to one.
 * @return {string} A RegExp safe, escaped copy of {@code s}.
 */
fnf.escapeRegex = function (s) {
    return String(s).replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g, "\\$1");
};


/**
 * Escapes dashes in a long word and inserts optional word break tags in-between
 * them so the UI can properly force-wrap when elements shrink.
 * @param {*} w The string to escape. If not a string, it will be casted to one.
 * @return {string} A properly word-broken copy of {@code w}.
*/
fnf.wordBreak = function (w) {
    if (!w) return w;
    return w.split("-").join("-<wbr />");
};


/**
  *All accepted date formats for the apps
*/
fnf.dateFormats = ["M/d/yyyy", "M/d/yy", "MM-dd-yyyy", "M-d-yyyy", "M-d-yy", "MMddyyyy", "MMddyy", "yyyy-MM-dd", "yyyy-M-d", "yyyy/MM/dd", "yyyy/M/d"];

fnf.formatDate = function (d) {
    if (!d) return "";
    var fn = $.isFunction(d) ? d() : d;
    if (!fn) return "";
    var m = moment(new Date(fn));
    if (m.isValid()) return m.format("MM/DD/YYYY");
    return fn;
};


/**
 * KendoUI utilities/helpers specific for all FNF UI implementations
 *
 **/
fnf.buildAutoCompleteDataSource = function (url, cache, filters, err) {
    var csrfToken = $("input[name='__RequestVerificationToken']").val();

    var headers = {
        'X-Requested-With': "XMLHttpRequest"
    };
    if (csrfToken) headers["RequestVerificationToken"] = csrfToken;
    return new kendo.data.DataSource({
        serverFiltering: true,
        serverPaging: true,
        pageSize: 20,
        serverSorting: true,
        transport: {
            read: {
                url: fnf.rest.resolveUrl(url),
                dataType: "jsonp",
                headers: headers,
                contentType: "application/json",
                cache: cache === true || cache == "true",
                data: function () {
                    if (filters) {
                        var f = filters;
                        if ($.isFunction(f)) {
                            f = f();
                        }
                        f = ko.toJS(f);
                        return f;
                    }
                    return null;
                }
            },
            parameterMap: function (data, type) {
                var m = "data=" + encodeURIComponent(kendo.stringify(data));
                return m;
            }
        },
        schema: {
            model: { id: "Id" },
            errors: "Message"
        },
        error: function (e) {
            var msg = {};
            try {
                msg = JSON.parse((e.xhr || {}).responseText || "{}");
            } catch (x) {
                msg = {};
            }
            fnf.error(msg.ExceptionMessage || msg.Message || e.errors || e.errorThrown || e.status, "Auto Complete Suggestion Lookup Failure");
            if (err) err(msg);
        }
    });
};
fnf.getKendoEventSource = function (e) {
    var def = {
        value: function () { return undefined; },
        text: function () { return undefined; },
        select: function () { return 0; },
        dataItem: function () { return undefined; },
        close: function () { }
    };
    if (!e) return def;
    if (!e.sender) return def;
    e.sender.value = e.sender.value || def.value;
    e.sender.text = e.sender.text || def.text;
    e.sender.select = e.sender.select || def.select;
    e.sender.dataItem = e.sender.dataItem || def.dataItem;
    return e.sender;
};
fnf.getKendoDataItem = function (e) {
    if (e && !e.sender && $.isPlainObject(e)) return e;
    var src = fnf.getKendoEventSource(e);
    return src.dataItem((e || {}).item) || (e || {}).item;
};

fnf.validateWidgetValueOrClear = function (widget, field, clear) {
    try {
        var v = widget.value();
        if (!v) return clear();
        if (!widget.dataItems || !widget.dataItems() || !widget.dataItems().length) return clear();
        for (var i = 0; i < widget.dataItems().length; i++) {
            if (v == widget.dataItems()[i][field]) return null;
        }
       return clear();
        
    } finally {
        widget.close();
    }
};

fnf.updateCartCount = function (path) {
    var url = path + 'Home/GetCartCount';
    fnf.rest.jsonpGet(url, function (success, data) {
        if (!success) {
            return;
        }
        if (data > 0)
            $('#cartcount').html(data);
        else
            $('#cartcount').html(0);
    });
};
