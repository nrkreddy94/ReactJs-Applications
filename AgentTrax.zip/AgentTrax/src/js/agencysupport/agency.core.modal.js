window.console = window.console || { console: function () { } }

//Do NOT delete these namespaces
var agency = agency || {};
agency.core = agency.core || {};

var fnf = fnf || {};
fnf.core = fnf.core || {};

agency.core.modal = function () {

    var messageTypes = {
        'success': 1,
        'error': 2,
        'warning': 3,
        'info': 4,
    };

    function errorConfig() {
        (window.toastr || {}).options = {
            closeButton: true,
            preventDuplicates: false,
            debug: false,
            progressBar: false,
            positionClass: "toast-top-full-width",
            onclick: null,
            tapToDismiss: true,
            showDuration: 300,
            hideDuration: 500,
            timeOut: 15000,
            extendedTimeOut: 15000,
            showEasing: "swing",
            hideEasing: "linear",
            showMethod: "fadeIn",
            hideMethod: "fadeOut"
        };
    }

    function standardConfig() {
        (window.toastr || {}).options = {
            positionClass: "toast-top-full-width",
            showDuration: 300,
            hideDuration: 500,
            timeOut: 5000,
            extendedTimeOut: 5000,
            showEasing: "swing",
            hideEasing: "linear",
            showMethod: "fadeIn",
            hideMethod: "fadeOut"
        };
    }

    function show(message, title, messageType) {

        switch (messageType) {
        case 1:
            standardConfig();
            window.toastr.success(message, title);
            break;
        case 2:
            errorConfig();
            window.toastr.error(message, title);
            break;
        case 3:
            errorConfig();
            window.toastr.warning(message, title);
            break;
        case 4:
            standardConfig();
            window.toastr.info(message, title);
            break;
        default:
            standardConfig();
            window.toastr.info(message, title);
        }
    }


    return {
        success: function(message, title) {
            show(message, title, messageTypes.success);
        },
        error: function(message, title) {
            show(message, title, messageTypes.error);
        },
        warning: function(message, title) {
            show(message, title, messageTypes.warning);
        },
        info: function(message, title) {
            show(message, title, messageTypes.info);
        }
    };
}();

fnf.core.modal = agency.core.modal;

window.fnf.error = function (msg, title) {
    if (!window.toastr) {
        alert("Error: " + msg);
    }
    window.agency.core.modal.error(msg, title);
};

window.fnf.warn = function (msg, title) {
    if (!window.toastr) {
        alert("Warning: " + msg);
    }
    window.agency.core.modal.warning(msg, title);
};

window.fnf.success = function (msg, title) {
    if (!window.toastr) {
        alert("Success: " + msg);
    }
    window.agency.core.modal.success(msg, title);
};

window.fnf.info = function (msg, title) {
    if (!window.toastr) {
        alert(msg);
    }
    window.agency.core.modal.info(msg, title);
};