const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");
var webpack = require('webpack');
var ExtractTextPlugin = require('extract-text-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin')

module.exports = {
    entry: "./src/index.js",
    output: {
       path: path.resolve(__dirname, 'react'),
		filename:'[name]-[hash].js'
		
    },
    devtool: 'source-map',
    devServer: {
    port: 3000,
    open: true,
    proxy:{
     '/api': 'http://localhost:9000'
    }
    
},
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: ["babel-loader"]
            },
            {
                test: /\.css$/,
                use: ExtractTextPlugin.extract({
                    use: 'css-loader',
                    fallback: 'style-loader'
                }),
            },
            {
                test: /\.(png|jpg|gif|jpeg|ico|woff(2)?|ttf|eot)$/,
                use: [
                    {
                        loader: 'file-loader?name=[name].[ext]',
                    }
                ]
            },
            {

                test: /\.svg$/,
                loader: 'svg-inline-loader'

            },
        ]
    },

    plugins: [
        new CleanWebpackPlugin(),
        new HtmlWebpackPlugin({
            template: "./public/index.html"
            
        }),
        new webpack.BannerPlugin("Copyright Flying Unicorns inc.By Jagadeesh"),
        new webpack.HotModuleReplacementPlugin(),
        new ExtractTextPlugin("[name]-[hash].css"),
         new webpack.ProvidePlugin({
            '$': "jquery",
            'jQuery': "jquery",
            'Popper': 'popper.js'
        })

    ]
}
